jQuery(document).ready(function () {
    analyze(deviceInput.userAgent, parseInt(deviceInput.maxPhoneWidth, 10));
    setTimeout(function () {
        jQuery('.carousel').carousel({
            interval: 5000
        })
        if(jQuery(window).width() < 767){           
            jQuery('.upcomingxs').css('visibility', 'hidden');
        }
        jQuery("#upcomingProducts .purchaseSpec button").on("click", function () {
            var currentPart = jQuery(this).parents(".productPlaceHolder").data("part");
            jQuery('#notifyModal').modal();
            jQuery(".notifyPartclick").html(currentPart);
        })

        jQuery('ul.productCat li.cat-item').on('click', function () {
            jQuery('li.cat-item').removeClass('cat-itemSel');
            if (jQuery('li.cat-item').find('i').hasClass('icon-st-accordionMinus')) {
                jQuery('li.cat-item').find('i').removeClass('icon-st-accordionMinus');
            }
            jQuery(this).addClass('cat-itemSel');
            jQuery(this).find('i').addClass('icon-st-accordionMinus');
            if (jQuery('ul.subCat').css('display', '')) {
                jQuery('ul.subCat').slideUp();
            }
            jQuery(this).nextAll('ul.subCat:first').slideDown();
        })
        jQuery('.prod-carousel').owlCarousel({
            loop: false,
            margin: 25,
            nav: true,
            navText: ["<img src='../icons/carleft.png' width='18px' height='30px'>", "<img src='../icons/carright.png' width='18px' height='30px'>"],
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                    nav: true,
                    loop: false,
                    margin: 15,
                    mouseDrag: true,
                    dots: false

                },
                600: {
                    items: 3,
                    nav: false,
                    loop: false,
                    margin: 15,
                    mouseDrag: true,
                    dots: false
                },
                1023: {
                    items: 3,
                    nav: true,
                    loop: false,
                    slideBy: 4,
                    mouseDrag: false
                },
                1200: {
                    items: 4,
                    nav: true,
                    loop: false,
                    margin: 10,
                    slideBy: 4,
                    mouseDrag: false
                }
            }
        })
        jQuery('.recentcarousel').owlCarousel({
            loop: false,
            margin: 25,
            nav: true,
            navText: ["<img src='../icons/carleft.png' width='18px' height='30px'>", "<img src='../icons/carright.png' width='18px' height='30px'>"],
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                    nav: true,
                    margin: 11,
                    loop: false,
                    mouseDrag: true,
                    dots: false
                },
                600: {
                    items: 1,
                    nav: false,
                    margin: 10,
                    loop: false,
                    mouseDrag: true,
                    dots: false
                },
                1023: {
                    items: 2,
                    nav: true,
                    loop: false,
                    mouseDrag: false,
                    slideBy: 3,
                },
                1200: {
                    items: 3,
                    nav: true,
                    loop: false,
                    mouseDrag: false,
                    slideBy: 3,
                }

            }
        })
        //start of tabs//
        jQuery('.productListingCat li').click(function () {
            var tab_id = jQuery(this).attr('data-tab');
            jQuery('.tab-content').removeClass('current');
            jQuery('.productListingCat li div').removeClass('current');
            jQuery(this).find("div").addClass('current');
            jQuery("#" + tab_id).addClass('current');
            if (jQuery(window).width() < 767) {
                jQuery('li').find('div i:eq(1)').css('visibility','hidden');
                jQuery(this).find('div.current i:eq(1)').css('visibility','visible');
            }
        })

        // wishlist script start
        jQuery('.text-right>i').on('click', function () {
            jQuery(this).toggleClass('icon-st-markfavSel');
        })
        jQuery('.latestcarousel').owlCarousel({
            loop: true,
            margin: 10,
            nav: true,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                    nav: true
                },
                600: {
                    items: 1,
                    nav: false
                },
                1000: {
                    items: 1,
                    nav: true,
                    loop: false
                }
            }
        })

        var mql = window.matchMedia("screen and (max-width: 768px)")
        mediaqueryresponse(mql) // call listener function explicitly at run time
        mql.addListener(mediaqueryresponse) // attach listener function to listen in on state changes


        //Deal of the day
        //count down timer start//
        var end = new Date(new Date().getTime()+(5*24*60*60*1000));
        var _second = 1000;
        var _minute = _second * 60;
        var _hour = _minute * 60;

        function clock() {

            var now = new Date();
            var distance = end - now;
            var hours = Math.floor(distance / _hour);
            var minutes = Math.floor((distance % _hour) / _minute);
            var seconds = Math.floor((distance % _minute) / _second);
            document.getElementById('hours').innerText = hours.toString().length == "1" ? "0" + hours : hours,
                document.getElementById('minutes').innerText = minutes.toString().length == "1" ? "0" + minutes : minutes,
                document.getElementById('seconds').innerText = seconds.toString().length == "1" ? "0" + seconds : seconds;
        }
        setInterval(clock, 1000);
        jQuery(".header-strip .leftspace a.nav-link").on('click', function () {
            if (!jQuery('.header-strip .leftspace').hasClass("show")) {
                if (jQuery('.modal-backdrop').length === 0) {
                    jQuery('body').append('<div class="modal-backdrop fade show headeActive"></div>');
                    jQuery('body').addClass('menuBackdrop');
                }
            } else {
                jQuery(".modal-backdrop.fade.show").remove();
                jQuery('body').removeClass('menuBackdrop');
            }
        })

        jQuery('body').not($(".header-strip, #header .dropdown-menu")).on('click', function () {
            if (jQuery('.header-strip .leftspace').hasClass("show")) {
                jQuery(".modal-backdrop.fade.show").remove();
                jQuery('body').removeClass('menuBackdrop');
            }
        })

    }, 2000);

    /// Sticky Header code, which is working.
    jQuery(window).scroll(function () {
        if ((jQuery(window).scrollTop() >= 115) && (jQuery(window).width() > 767)) {
            jQuery('#navigation-container').addClass('fixed-header').slideDown(500);
            jQuery('[role^="rightnaveholder"] .fastxs, [role^="rightnaveholder"] .accountxs, [role^="rightnaveholder"] .servicexs').hide();
            //jQuery('[role^="rightnaveholder"] .account .icon-st-downarrow').show(); 
        } else if ((jQuery(window).scrollTop() >= 65) && (jQuery(window).width() < 767)) {
            jQuery('#header').slideDown(1000).addClass('fixed-header');
            jQuery('[role^="rightnaveholder"] .fastxs, [role^="rightnaveholder"] .accountxs, [role^="rightnaveholder"] .servicexs').hide();
            //jQuery('[role^="rightnaveholder"] .account .icon-st-downarrow').hide(); 
        } else {
            jQuery('#header, #navigation-container').removeClass('fixed-header');
            jQuery('[role^="rightnaveholder"] .fastxs, [role^="rightnaveholder"] .accountxs, [role^="rightnaveholder"] .servicexs').show();
        }
    });
})

function mediaqueryresponse(mql) {
    if (mql.matches) {
        jQuery(".taber").attr("data-toggle", "collapse");
        jQuery('.collapse').collapse("hide");
    } else {
        jQuery('.collapse').collapse("show");
        jQuery("[data-toggle='collapse']").removeAttr("data-toggle");
    }
}

//end of tab//

// wishlist script start
/*jQuery('.text-right').on('click', function(){debugger;
    jQuery(this).find('i').toggleClass('icon-st-markfavSel');
})*/
